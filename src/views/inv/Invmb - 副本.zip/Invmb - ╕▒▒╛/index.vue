<template>
    <el-collapse v-model="activeNames">
        <el-collapse-item title="查询条件" name="1" style="">
            <el-card class="form" style="">
                <conditionGroup :floor="floor" :conditionList="conditionList" :key-list="keyOptions"
                    :val-list="valueOptions"> </conditionGroup>
                <el-button type="primary" size="default" @click="query">查询</el-button>
            </el-card>
        </el-collapse-item>
    </el-collapse>
    <el-card style="margin: 10px 0px;">
        <el-button type="primary" size="default" @click="addUser">添加品号</el-button>
        <el-button type="primary" size="default" :disabled="selectIdArr.length ? false : true"
            @click="deleteSelectUser">批量删除</el-button>
        <el-button type="primary" size="default" @click="exportExcel('品号信息.xlsx', '#invmb-table')">导出EXCEL</el-button>
        <el-icon :size="20" style="float: right; font-size: 33px; padding-right:50px" class="grid">
            <el-popover placement="bottom" trigger="hover" width="80">
                <template #reference>
                    <el-button>
                        <Grid />
                    </el-button>
                </template>


                <div id="elcheckbox">
                    <div class="basicEx">
                        <el-checkbox v-model="basicCheckAllEx" :indeterminate="isbasicminateEx"
                            @change="handleBasicAllChangeEx">全选</el-checkbox>
                    </div>
                    <el-checkbox-group v-model="invmbTableFilter" @change="handleCheckBoxChange" class="checkbox-wrap">
                        <VueDraggableNext v-model="columns" @end="handleCheckBoxChange">
                            <el-checkbox v-for="(col, index) in columns" :key="index" :label="col.label" size="large"
                                style="display: block" />
                        </VueDraggableNext>
                    </el-checkbox-group>
                </div>



                <!-- <div id="elcheckbox">

                    <el-checkbox-group v-model="invmbTableFilter" @change="handleCheckBoxChange" class="checkbox-wrap">
                        <el-checkbox v-for="(col, index) in columns" :label="col.label" size="large"
                            style="display: block" />
                    </el-checkbox-group>
                </div>-->
            </el-popover>
        </el-icon>



        <!-- table展示用户信息 -->
        <vtable id="invmb-table" :tableData="invmbArr" :height="vtbheight" :columns="columns" :sumArray="getSum"
            :row-class-name="tableRowClassName" :checkVhide=true :butPremission="true"
            @invmbShowInventory="getInventory">
        </vtable>
        <!-- <el-table @selection-change="selectChange" style="margin: 10px 0px;" border :data="invmbArr">
            <el-table-column type="selection" align="center"></el-table-column>
            <el-table-column label="#" align="center" type="index"></el-table-column>
            <el-table-column label="品号" align="center" prop="MB001"></el-table-column>
            <el-table-column label="品名" align="center" prop="MB002" show-overflow-tooltip></el-table-column>
            <el-table-column label="规格" align="center" prop="MB003" show-overflow-tooltip></el-table-column>
            <el-table-column label="手机" align="center" prop="MB005" show-overflow-tooltip></el-table-column>
            <el-table-column label="Email" align="center" prop="MB011" show-overflow-tooltip></el-table-column>
            <el-table-column label="用户角色" align="center" prop="MB014" show-overflow-tooltip></el-table-column>
            <el-table-column label="创建时间" align="center" prop="MB017" show-overflow-tooltip></el-table-column>
            <el-table-column label="更新时间" align="center" prop="MB018" show-overflow-tooltip></el-table-column>
            <el-table-column label="品号" align="center" prop="MB019"></el-table-column>
            <el-table-column label="品名" align="center" prop="MB021" show-overflow-tooltip></el-table-column>
            <el-table-column label="规格" align="center" prop="MB022" show-overflow-tooltip></el-table-column>
            <el-table-column label="手机" align="center" prop="MB025" show-overflow-tooltip></el-table-column>
            <el-table-column label="Email" align="center" prop="MB026" show-overflow-tooltip></el-table-column>
            <el-table-column label="用户角色" align="center" prop="MB027" show-overflow-tooltip></el-table-column>
            <el-table-column label="创建时间" align="center" prop="MB028" show-overflow-tooltip></el-table-column>
            <el-table-column label="更新时间" align="center" prop="MB029" show-overflow-tooltip></el-table-column>
            <el-table-column label="操作" width="300px" align="center">
                <template #="{ row, $index }">
                    <el-button type="primary" size="small" icon="User" @click="setRole(row)">分配角色</el-button>
                    <el-button type="primary" size="small" icon="Edit" @click="updateUser(row)">编辑</el-button>
                    <el-popconfirm :title="`你确定要删除${row.username}?`" width="260px" @confirm="deleteUser(row.id)">
                        <template #reference>
                            <el-button type="primary" size="small" icon="Delete">删除</el-button>
                        </template>
                    </el-popconfirm>
                </template>
            </el-table-column>
        </el-table> -->
        <!-- 分页器 -->
        <el-pagination v-model:current-page="pageNo" v-model:page-size="pageSize" :page-sizes="[10, 30, 100, 500, 2000]"
            :background="true" layout="prev, pager, next, jumper,->,sizes,total" :total="total"
            @current-change="getHasUser" @size-change="handler" />
    </el-card>
    <!-- 抽屉结构:完成添加新的用户账号|更新已有的账号信息 -->
    <el-drawer v-model="drawer">
        <!-- 头部标题:将来文字内容应该动态的 -->
        <template #header>
            <h4>{{ userParams.id ? '更新用户' : '添加用户' }}</h4>
        </template>
        <!-- 身体部分 -->
        <template #default>
            <el-form :model="userParams" :rules="rules" ref="formRef">
                <el-form-item label="用户姓名" prop="username">
                    <el-input placeholder="请您输入用户姓名" v-model="userParams.username"></el-input>
                </el-form-item>
                <el-form-item label="用户昵称" prop="name">
                    <el-input placeholder="请您输入用户昵称" v-model="userParams.name"></el-input>
                </el-form-item>
                <el-form-item label="用户密码" prop="password" v-if="!userParams.id">
                    <el-input placeholder="请您输入用户密码" v-model="userParams.password"></el-input>
                </el-form-item>
                <el-form-item label="用户手机" prop="mobile">
                    <el-input placeholder="请您输入用户手机" v-model.number="userParams.mobile"></el-input>
                </el-form-item>
                <el-form-item label="用户邮箱" prop="email">
                    <el-input placeholder="请您输入用户邮箱" v-model="userParams.email"></el-input>
                </el-form-item>
            </el-form>
        </template>
        <template #footer>
            <div style="flex: auto">
                <el-button @click="cancel">取消</el-button>
                <el-button type="primary" @click="save">确定</el-button>
            </div>
        </template>
    </el-drawer>
    <!-- 抽屉结构:用户某一个已有的账号进行职位分配 -->
    <el-drawer v-model="drawer1">
        <template #header>
            <h4>分配角色(职位)</h4>
        </template>
        <template #default>
            <el-form>
                <el-form-item label="用户姓名">
                    <el-input v-model="userParams.username" :disabled="true"></el-input>
                </el-form-item>
                <el-form-item label="职位列表">
                    <el-checkbox @change="handleCheckAllChange" v-model="checkAll"
                        :indeterminate="isIndeterminate">全选</el-checkbox>
                    <!-- 显示职位的的复选框 -->
                    <el-checkbox-group v-model="userRole" @change="handleCheckedCitiesChange">
                        <el-checkbox v-for="(role, index) in allRole" :key="index" :label="role">{{ role.roleName
                            }}</el-checkbox>
                    </el-checkbox-group>
                </el-form-item>
            </el-form>
        </template>
        <template #footer>
            <div style="flex: auto">
                <el-button @click="drawer1 = false">取消</el-button>
                <el-button type="primary" @click="confirmClick">确定</el-button>
            </div>
        </template>
    </el-drawer>
    <!-- 查询库存可用量:展示框 -->
    <el-dialog v-model="dialogVisible" style="width:420px;" title="查询库存状况-查各库库存量">
        <el-form class="elInventory" :model="InventoryData" :rules="rules" ref="form">
            <div class="form-top">
                <div class="form-top--left">
                    <el-form-item label="预计请购" prop="YJQG">
                        <el-input v-model="InventoryData.YJQG" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="预计进货" prop="YJJH">
                        <el-input v-model="InventoryData.YJJH" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="预计生产" prop="YJSC">
                        <el-input v-model="InventoryData.YJSC" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="计划采购" prop="JHCG">
                        <el-input v-model="InventoryData.JHCG" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="计划生产" prop="JHSC">
                        <el-input v-model="InventoryData.JHSC" readonly></el-input>
                    </el-form-item>

                    <el-form-item label="预计可用" prop="YJKY">
                        <el-input v-model="InventoryData.YJKY" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="计划可用" prop="JHKY">
                        <el-input v-model="InventoryData.JHKY" readonly></el-input>
                    </el-form-item>

                    <el-form-item label="库存数量" prop="KCSL">
                        <el-input v-model="InventoryData.KCSL" readonly></el-input>
                    </el-form-item>
                </div>
                <div class="form-top--right">
                    <el-form-item label="预计领用" prop="YJLY">
                        <el-input v-model="InventoryData.YJLY" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="预计销货" prop="YJXH">
                        <el-input v-model="InventoryData.YJXH" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="计划领用" prop="JHLY">
                        <el-input v-model="InventoryData.JHLY" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="计划销货" prop="JHXH">
                        <el-input v-model="InventoryData.JHXH" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="待领用量" prop="DLSL">
                        <el-input v-model="InventoryData.DLSL" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="待销货量" prop="DXSL">
                        <el-input v-model="InventoryData.DXSL" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="待验收量" prop="DYSL">
                        <el-input v-model="InventoryData.DYSL" readonly></el-input>
                    </el-form-item>
                </div>



            </div>

        </el-form>
        <template #footer>
            <el-button type="primary" size="default" @click="dialogVisible = false">关闭</el-button>
        </template>
    </el-dialog>
</template>
<script setup lang="ts">
import vtable from "@/components/Table/index.vue"
import useLayOutSettingStore from '@/store/modules/setting';
import { ref, onMounted, onBeforeMount, reactive, nextTick, watch } from 'vue';
import { reqSelectUser, reqRemoveUser, reqUserInfo, reqAddOrUpdateUser, reqAllRole, reqSetUserRole } from '@/api/acl/user'
import { reqInvmbInfo, reqInventory } from "@/api/inv/invmb";
import type { SetRoleData, UserResponseData, User, AllRoleResponseData, AllRole } from '@/api/acl/user/type';
import type { Records, InvmbResponseData, requestcontion, conditions, Inventory, InventoryResponseData } from '@/api/inv/invmb/type';
import { ElMessage } from 'element-plus';
import conditionGroup from "@/components/filter/conditionGroup.vue";
import { exportExcel } from "@/utils/exportExcel";
import { fa } from "element-plus/es/locale";
//默认页码
let pageNo = ref<number>(1);
//一页展示几条数据
let pageSize = ref<number>(10);
//用户总个数
let total = ref<number>(0);
//存储全部用户的数组
let invmbArr = ref<Records>([]);
//定义响应式数据控制抽屉的显示与隐藏
let drawer = ref<boolean>(false);
//控制分配角色抽屉显示与隐藏
let drawer1 = ref<boolean>(false);
//存储全部职位的数据
let allRole = ref<AllRole>([]);
//当前用户已有的职位
let userRole = ref<AllRole>([]);
//收集用户信息的响应式数据
let userParams = reactive<User>({
    username: '',
    name: '',
    password: '',
    mobile: '',
    email: ''
});
//准备一个数组存储批量删除的用户的ID
let selectIdArr = ref<User[]>([]);
//获取form组件实例
let formRef = ref<any>();
//定义响应式数据:收集用户输入进来的关键字
let keyword = ref<string>('');
//获取模板setting仓库
let settingStore = useLayOutSettingStore();
//定义el-chekcbox-group绑定的展示列变量
let invmbTableFilter = ref<string[]>([])
//页面渲染之前
onBeforeMount(() => {
    //判断本地绑在是否有TABLE的自定义筛选数据，有则启用筛选，无的默认展示所有列信息
    if (localStorage.getItem('invmbTableFilter')) {
        invmbTableFilter.value = JSON.parse(localStorage.getItem('invmbTableFilter') || '');
        handleCheckBoxChange(invmbTableFilter.value);
    } else {
        invmbTableFilter.value = columns.value.map(item => item.label);
    }
});
//组件挂载完毕
onMounted(async () => {
    await getHasUser();
});

/*******************************************/
//用于控制查询条件显示\折叠的变量
const activeNames = ref('1')
//定义V-TABLE的高度变量
const vtbheight = ref(window.innerHeight - 316)
//默认查询条件的参数
const condition = {
    id: '1',
    index: 1,
    condition: 'equal',
    operate: 'and',
    field: '',
    value: '',
    header: true,
    checked: true,
    pid: -1,
    floor: 1
};
//搜集查询条件数据的集合
const conditionList = [Object.assign({}, condition)];
let floor = 1;
//查询筛选条件的Key
const keyOptions = [
    { 'key': '品号', 'val': 'MB001' },
    { 'key': '品名', 'val': 'MB002' },
    { 'key': '规格', 'val': 'MB003' },
    { 'key': '库存数量', 'val': 'MB064' },
    { 'key': '库存金额', 'val': 'MB065' },
    { 'key': '存货管理', 'val': 'MB019' },
    { 'key': '核准状况', 'val': 'MB109' },
    { 'key': '生效日期', 'val': 'MB030' }
];

//定义筛选值的选项
const valueOptions = {
    MB019: {
        dom: 'select',
        data: [
            { 'key': '是', 'val': 'Y' },
            { 'key': '否', 'val': 'N' },
        ]
    },
    MB109: {
        dom: 'select',
        data: [
            { 'key': '已核准', 'val': 'Y' },
            { 'key': '尚待核准', 'val': 'y' },
            { 'key': '不准交易', 'val': 'N' },

        ]
    },
    MB030: {
        dom: 'date'
    }
};
const query = () => {
    //console.log(conditionList)
    getHasUser()
};

/********************************************************************* */
//获取全部已有的用户信息
const getHasUser = async (pager = 1) => {
    //收集当前页码
    pageNo.value = pager;
    let testt = { conditions: [{}] }
    testt.conditions.splice(0, 1)
    //let data = JSON.stringify(conditionList)
    conditionList.forEach(element => {
        testt.conditions.push(element)
    });
    let result: InvmbResponseData = await reqInvmbInfo(pageNo.value, pageSize.value, testt);

    if (result.code == 200) {
        total.value = result.data.total;
        result.data.records.forEach((item, index) => {
            item.index = index + 1 + (pageNo.value - 1) * pageSize.value;
        });
        invmbArr.value = result.data.records;
    }
}
//获取库存可用量信息
const getInventory = async (strPH: string, strDate: string) => {
    debugger;
    let result: InventoryResponseData = await reqInventory(strPH, strDate);
    if (result.code == 200) {
        InventoryData = result.data;
        dialogVisible.value = true;
    }
}
//分页器下拉菜单的自定义事件的回调
const handler = () => {
    getHasUser();
}
//添加用户按钮的回调
const addUser = () => {
    //抽屉显示出来
    drawer.value = true;
    //清空数据
    Object.assign(userParams, {
        id: 0,
        username: '',
        name: '',
        password: '',
        email: '',
        mobile: ''
    });
    //清除上一次的错误的提示信息
    nextTick(() => {
        formRef.value.clearValidate('username');
        formRef.value.clearValidate('name');
        formRef.value.clearValidate('password');
        formRef.value.clearValidate('email');
        formRef.value.clearValidate('mobile');
    });
}

//更新已有的用户按钮的回调
//row:即为已有用户的账号信息
const updateUser = (row: User) => {
    //抽屉显示出来
    drawer.value = true;
    //存储收集已有的账号信息
    Object.assign(userParams, row);
    //清除上一次的错误的提示信息
    nextTick(() => {
        formRef.value.clearValidate('username');
        formRef.value.clearValidate('name');
        formRef.value.clearValidate('email');
        formRef.value.clearValidate('mobile');
    });
}
//保存按钮的回调
const save = async () => {
    //点击保存按钮的时候,务必需要保证表单全部复合条件在去发请求
    await formRef.value.validate()
    //保存按钮:添加新的用户|更新已有的用户账号信息
    let result: any = await reqAddOrUpdateUser(userParams);
    //添加或者更新成功
    if (result.code == 200) {
        //关闭抽屉
        drawer.value = false;
        //提示消息
        ElMessage({ type: 'success', message: userParams.id ? '更新成功' : '添加成功' });
        //获取最新的全部账号的信息
        // getHasUser(userParams.id ? pageNo.value : 1);
        //浏览器自动刷新一次
        window.location.reload();
    } else {
        //关闭抽屉
        drawer.value = false;
        //提示消息
        ElMessage({ type: 'error', message: userParams.id ? '更新失败' : '添加失败' });
    }
}
//取消按钮的回调
const cancel = () => {
    //关闭抽屉
    drawer.value = false;
}
//校验用户名字回调函数
const validatorUsername = (rule: any, value: any, callBack: any) => {
    //用户名字|昵称,长度至少五位
    if (value.trim().length >= 2) {
        callBack();
    } else {
        callBack(new Error('用户名字至少五位'))
    }
}
//校验用户名字回调函数
const validatorname = (rule: any, value: any, callBack: any) => {
    //用户名字|昵称,长度至少五位
    if (value.trim().length >= 2) {
        callBack();
    } else {
        callBack(new Error('用户昵称至少五位'))
    }
}
//校验用户密码必须大于等于六位
const validatorPassword = (rule: any, value: any, callBack: any) => {
    //用户名字|昵称,长度至少五位
    if (value.trim().length >= 6) {
        callBack();
    } else {
        callBack(new Error('用户密码至少六位'))
    }
}
//校验用户邮箱回调函数
const validatorEmail = (rule: any, value: any, callBack: any) => {
    if (value === '') {
        callBack(new Error("请正确填写邮箱"))
    } else {
        if (value !== '请正确填写邮箱') {
            var reg = /^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;
            if (!reg.test(value)) {
                callBack(new Error('邮箱地址格式不对'))
            }
        }
        callBack()
    }
}
//校验用户手机号
const validatorMobile = (rule: any, value: any, callBack: any) => {
    const regExp = /^(0|86|17951)?(13[0-9]|15[012356789]|166|17[3678]|18[0-9]|14[57])[0-9]{8}$/
    if (!regExp.test(value)) {
        callBack(new Error('请输入正确的手机号'))
    } else {
        callBack()
    }
}
//表单校验的规则对象
const rules = {
    //用户名字
    username: [{ required: true, trigger: 'blur', validator: validatorUsername }],
    //用户昵称
    name: [{ required: true, trigger: 'blur', validator: validatorname }],
    //用户的密码
    password: [{ required: true, trigger: 'blur', validator: validatorPassword }],
    //用户邮箱
    email: [{ required: true, trigger: 'blur', validator: validatorEmail }],
    //用户手机
    mobile: [{ required: true, trigger: 'blur', validator: validatorMobile }]
}
//分配角色按钮的回调
const setRole = async (row: User) => {
    //存储已有的用户信息
    Object.assign(userParams, row);
    //获取全部的职位的数据与当前用户已有的职位的数据
    let result: AllRoleResponseData = await reqAllRole((userParams.id as number));
    if (result.code == 200) {
        //存储全部的职位
        allRole.value = result.data.allRolesList;
        //存储当前用户已有的职位
        userRole.value = result.data.assignRoles;
        //抽屉显示出来
        drawer1.value = true;
    }

}

//收集顶部复选框全选数据
const checkAll = ref<boolean>(false);
//控制顶部全选复选框不确定的样式
const isIndeterminate = ref<boolean>(true);
//顶部的全部复选框的change事件
const handleCheckAllChange = (val: boolean) => {
    //val:true(全选)|false(没有全选)
    userRole.value = val ? allRole.value : [];
    //不确定的样式(确定样式)
    isIndeterminate.value = false
}
//顶部全部的复选框的change事件
const handleCheckedCitiesChange = (value: string[]) => {
    //顶部复选框的勾选数据
    //代表:勾选上的项目个数与全部的职位个数相等，顶部的复选框勾选上
    checkAll.value = value.length === allRole.value.length;
    //不确定的样式
    isIndeterminate.value = value.length !== allRole.value.length
}
//确定按钮的回调(分配职位)
const confirmClick = async () => {
    //收集参数
    let data: SetRoleData = {
        userId: (userParams.id as number),
        roleIdList: userRole.value.map(item => {
            return (item.id as number)
        })
    }
    //分配用户的职位
    let result: any = await reqSetUserRole(data);
    if (result.code == 200) {
        //提示信息
        ElMessage({ type: 'success', message: '分配职务成功' });
        //关闭抽屉
        drawer1.value = false;
        //获取更新完毕用户的信息,更新完毕留在当前页
        getHasUser(pageNo.value);

    }
}

//删除某一个用户
const deleteUser = async (userId: number) => {
    let result: any = await reqRemoveUser(userId);
    if (result.code == 200) {
        ElMessage({ type: 'success', message: '删除成功' });
        getHasUser(invmbArr.value.length > 1 ? pageNo.value : pageNo.value - 1);
    }
}
//table复选框勾选的时候会触发的事件
const selectChange = (value: any) => {
    selectIdArr.value = value;
}
//批量删除按钮的回调
const deleteSelectUser = async () => {
    //整理批量删除的参数
    let idsList: any = selectIdArr.value.map(item => {
        return item.id;
    });
    //批量删除的请求
    let result: any = await reqSelectUser(idsList);
    if (result.code == 200) {
        ElMessage({ type: 'success', message: '删除成功' });
        getHasUser(invmbArr.value.length > 1 ? pageNo.value : pageNo.value - 1);
    } else if (result.code == 201) {
        ElMessage({ type: 'error', message: '操作失败，请联系系统管理员！' });
    }
}

//搜索按钮的回调
const search = () => {
    //根据关键字获取相应的用户数据
    getHasUser();
    //清空关键字
    keyword.value = '';
}
//重置按钮
const reset = () => {
    settingStore.refsh = !settingStore.refsh;
}

const columns = ref([

    { strlen: 10, label: "品号", prop: "MB001", width: 120, vhide: false, orderby: true, isShow: true, sort: 0 },
    { strlen: 5, label: "品名", prop: "MB002", width: 120, vhide: true, isShow: true, sort: 0 },
    { strlen: 10, label: "规格", prop: "MB003", width: 230, vhide: true, isShow: true, sort: 0 },
    { strlen: 5, label: "品号分类", prop: "MB005", width: 85, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "主要仓库", prop: "MB017", width: 85, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "库存单位", prop: "MB004", width: 85, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "存货管理", prop: "MB019", width: 85, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "品号属性", prop: "MB025", width: 85, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "补货政策", prop: "MB034", width: 85, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "补货周期", prop: "MB035", width: 85, vhide: false, isShow: true, sort: 0 },
    { strlen: 8, label: "固定前置天数", prop: "MB036", width: 110, vhide: true, isShow: true, sort: 0 },
    { strlen: 5, label: "变动前置天数", prop: "MB037", width: 110, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "批量", prop: "MB038", width: 60, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "最低补量", prop: "MB039", width: 85, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "补货倍量", prop: "MB040", width: 85, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "领用倍量", prop: "MB041", width: 85, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "领料码", prop: "MB042", width: 65, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "单位标准材料成本", prop: "MB037", width: 120, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "单位标准人工成本", prop: "MB058", width: 120, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "单位标准制造费用", prop: "MB059", width: 180, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "单位标准加工费用", prop: "MB060", width: 120, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "本阶人工", prop: "MB061", width: 120, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "本阶制费", prop: "MB062", width: 120, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "本阶加工", prop: "MB063", width: 120, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "库存数量", prop: "MB064", width: 120, vhide: false, orderby: true, isShow: true, sort: 0 },
    { strlen: 5, label: "库存金额", prop: "MB065", width: 120, vhide: false, orderby: true, isShow: true, sort: 0 },
    { strlen: 5, label: "更改品名规格", prop: "MB066", width: 120, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "工作中心", prop: "MB068", width: 120, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "品号类别", prop: "MB077", width: 120, vhide: false, isShow: true, sort: 0 },
    { strlen: 5, label: "品号图片", prop: "MB143", width: 120, vhide: false, isShow: true, sort: 0 },
    { strlen: 18, label: "库存状况", prop: "", width: 220, vhide: false, isShow: true, sort: 0 },

]);

const getSum = ["MB064", "MB065"];
const tableRowClassName = (row: any, rowIndex: any) => {
    if ((row.rowIndex + 1) % 2 === 0) {
        return "oddRow";
    }
    return "evenRow";
};
watch(activeNames, (newVal, oldVal) => {
    if (activeNames.value == '1') {
        vtbheight.value = window.innerHeight - 316
    } else {
        vtbheight.value = window.innerHeight - 228
    }
})






const checkboxselect = ref(columns.value.map(item => item.label))
const handleCheckBoxChange = (val: string[]) => {
    columns.value.forEach(item => {
        if (val.includes(item.label)) {
            item.isShow = true
            item.sort = val.indexOf(item.label) - val.length
        } else {
            item.isShow = false
        }
    })
    columns.value.sort((a, b) => a.sort - b.sort)
    localStorage.setItem('invmbTableFilter', JSON.stringify(val));
    const checkedCountBasicEx = val.length
    basicCheckAllEx.value = checkedCountBasicEx === columns.value.length
    isbasicminateEx.value = checkedCountBasicEx > 0 && checkedCountBasicEx < columns.value.length
}
const basicCheckAllEx = ref(false)
const isbasicminateEx = ref(false)
const handleBasicAllChangeEx = (val: any) => {
    invmbTableFilter.value = val ? columns.value.map(item => item.label) : [];
    isbasicminateEx.value = false;
    handleCheckBoxChange(invmbTableFilter.value);
}
const dialogVisible = ref(false)
let InventoryData = reactive<Inventory>({
    PH: "123456",
    YJQG: 0,
    YJJH: 0,
    YJSC: 0,
    YJLY: 0,
    YJXH: 0,
    KCSL: 0,
    YJKY: 0,
    JHCG: 0,
    JHSC: 0,
    JHLY: 0,
    JHXH: 0,
    JHKY: 0,
    DYSL: 0,
    DLSL: 0,
    DXSL: 0
});

</script>

<style lang="scss" scoped>
.form {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-top: 10px;

    :deep(.el-card__body) {
        display: flex;
        justify-content: space-between;
        align-items: center;

        button {
            margin-left: 25px;

        }
    }
}

::-webkit-scrollbar {
    width: 10px;
    height: 18px;
    background-color: #5ca4bb;
}

// :deep( .el-table__body-wrapper::-webkit-scrollbar-track){
//     background-color: rgba(255,255,255,0);
// }
// :deep( .el-table__body-wrapper::-webkit-scrollbar){
//     height:20px;
//     width: 18px;
//     opacity: 0.5;
// }
// :deep( .el-table__body-wrapper::-webkit-scrollbar-thumb){
//     border-radius: 15px;
//     background-color: #cdd9e6;
// }






:deep(.el-collapse-item__content) {
    padding-bottom: 0px;
}

:deep(.el-table) .oddRow {
    --el-table-tr-bg-color: var(--el-color-warning-light-9);
    //    background: #e3f0da !important; 
}

:deep(.el-table .evenRow) {
    --el-table-tr-bg-color: var(--el-color-success-light-9);
    //   background-color: #6c8d90;
}


/* 鼠标悬停当前行颜色 有fixed固定列时*/
:deep(.el-table__body) .el-table__row.hover-row td {
    background-color: #5ca4bb !important; //暗黑模式

}

// 鼠标点击时行的颜色
:deep(.el-table__body tr.current-row)>td {
    background: #5ca4bb !important;
}

:deep(.checkbox-wrap .el-checkbox) {
    height: 30px;
    max-height: 55px;

}

.form-top {
    display: flex;
    justify-content: space-between;
    .form-top--left{
        padding-right: 10px;
    }
    .form-top--right {
        flex: 1;
    }
}

#elcheckbox {
    height: 180px;
    width: 150px;
    overflow-y: scroll;
}

.elInventory .el-input__inner {
    border-radius: 10px;
    /* 圆角边框 */
    border-color: #0972ea;
    /* 边框颜色 */
    padding: 0 2px;
    /* 内边距 */
    font-size: 14px;
    /* 字体大小 */
    height: 10px;
    /* 高度 */
    width: 80px;
}

.elInventory .el-input {
    width: 150px;
}

.elInventory .el-form-item {
    margin-bottom: 5px;
}
</style>